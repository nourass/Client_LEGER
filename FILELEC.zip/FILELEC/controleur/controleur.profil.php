<?php

	require_once("vue/vue_profil.php");

?>